package com.tourismsatara.TourismSatara;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TourismSataraApplication {

	public static void main(String[] args) {
		SpringApplication.run(TourismSataraApplication.class, args);
	}

}
